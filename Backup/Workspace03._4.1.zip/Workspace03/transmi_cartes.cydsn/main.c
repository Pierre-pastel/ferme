/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include "string.h"
uint8 cptcar;    
uint16 compteur;
char message[100];

char data[6];       // [REGUL,PANN,BATT
char niv_reserv[3]; // [RESERV]
char niv_puits[3];  // [PUITS}
  
/********************************************START lecture niveau d'eau********************************************/
void lecture_reserv(){
    uint8 niv;

    niv=niveau_Read(); 
    
    if ( niv==0xFF) strcpy (niv_reserv,"00");
    if ( niv==0xFE) strcpy (niv_reserv,"02");
    if ( niv==0xFC) strcpy (niv_reserv,"04");
    if ( niv==0xF8) strcpy (niv_reserv,"06");
    if ( niv==0xF0) strcpy (niv_reserv,"08");
    if ( niv==0xE0) strcpy (niv_reserv,"10");
    if ( niv==0xC0) strcpy (niv_reserv,"12");
    if ( niv==0x80) strcpy (niv_reserv,"14");
    if ( niv==0x00) strcpy (niv_reserv,"16"); 
    if((niv!=0xFF)&&(niv!=0xFE)&&(niv!=0xFC)&&(niv!=0xF8)&&(niv!=0xF0)&&(niv!=0xE0)&&(niv!=0xC0)&&(niv!=0x80)&&(niv!=0x00))strcpy (niv_reserv,"99");
    
   
}
/********************************************END lecture niveau d'eau********************************************/


/********************************************START lecture LEDS********************************************/
void lecture_leds(){ 
    uint16 var;  
/*<---Lecture led verte bicolore batterie--->*/
    CyDelay(100);
    compteur=0;
    isr_vbat_Start();
    CyDelay(10000);
    isr_vbat_Stop();
    var=compteur;
    /****TEST LED ON FIXE****/
    if(compteur>490  && compteur<510){
        compteur=0;
        isr_rbat_Start();
        CyDelay(10000);
        isr_rbat_Stop();
        var=compteur;
        if(compteur>490  && compteur<510){//SOUSTENSION
            data[1]=4; }
    }
    else{//U NORMALE
        data[1]=1;
    }
    /****TEST CLIGNOTEMENT RAPIDE****/
    if(compteur>225  && compteur<245){//SURTENSION
       data[1]=3;  }
    /****TEST CLIGNOTEMENT LENT****/
    if(compteur>245  && compteur<255){//COMPLET
       data[1]=2; 
    }    
    
/*<---Lecture led rouge bicolore batterie--->*/
    CyDelay(100);
    compteur=0;
    isr_rbat_Start();
    CyDelay(10000);
    isr_rbat_Stop();
    var=compteur;
    /****TEST LED ON FIXE****/
    if(compteur>495  && compteur<505){//BATTERIE DECHARGEE++
        data[1]=5;
    }    
    
    /*<---Lecture led verte panneau--->*/
    CyDelay(100);
    compteur=0;
    isr_vpan_Start();
    CyDelay(10000);
    isr_vpan_Stop();
    var=compteur;
    /****TEST LED ON FIXE****/
    if(compteur>495  && compteur<505){//U FAIBLE
        data[0]='2'; }
    /****TEST LED OFF****/
    if(compteur<100){//AUCUNE U (ex nuit)
        data[0]=1;  }
    /****TEST CLIGNOTEMENT LENT****/
    if(compteur>245  && compteur<255){//EN CHARGE
        data[0]=3;   
    }
    
    
    /*<---Lecture led rouge charge--->*/
    CyDelay(100);
    compteur=0;
    isr_rch_Start();
    CyDelay(10000);
    isr_rch_Stop();
    var=compteur;
    /****TEST LED ON FIXE****/
    if(compteur>495  && compteur<505){//U NORMAL
        data[2]=0; }
    /****TEST LED CLIGNOTEMENT RAPIDE****/
    if(compteur>225  && compteur<245){//COURT CIRCUIT
        data[2]=2;  }
    /****TEST CLIGNOTEMENT LENT****/
    if(compteur>245  && compteur<255){//SURCHARGE
        data[2]=1;  }
    /****TEST LED OFF****/
    if(compteur<100){//DISJONCTE
        data[2]=3; 
    }    
    
    
}
/********************************************END lecture LEDS********************************************/


/********************************************START Reception puits********************************************/

/********************************************END Reception puits********************************************/

/********************************************START Envoi Sigfox********************************************/
void sigfox_init()
    {
     //initialisation du module sigfox
    UART_SIG_Start();
    CyDelay(1000);
    UART_SIG_PutString("ATE1\r");
    UART_SIG_PutString("ATQ0\r");
    CyDelay(1000);
    }



/********************************************START Envoi Sigfox********************************************/
void sigfox_send()
 {
    //variables locales
    uint8 i,nb;
    uint8 sigfox[40];
    UART_SIG_PutString("AT$SF=");
    //Cas de fonctionement normal : disjoncteur OK
    
     if(data[2]!=3){
        for(i=0;i<6;i++){
            UART_SIG_PutChar(data[i]+0x30);
            }
        
        UART_SIG_PutChar(niv_reserv[0]);
        UART_SIG_PutChar(niv_reserv[1]);
        UART_SIG_PutString("\r");
        }
   // cas de fonctionnement anormal
    else {
        for(i=0;i<6;i++){
            UART_SIG_PutChar(data[i]+0x30);
            }
        UART_SIG_PutChar(niv_reserv[0]);
        UART_SIG_PutChar(niv_reserv[1]);
        UART_SIG_PutString(",1,1\r");
        UART_SIG_ClearRxBuffer();
        //début traitement réception
        cptcar=0;
        isr_1_Start();
        
        /*nb=0;
        do{
            sigfox[nb]=UART_SIG_GetChar();
            nb++;
            
        }while(sigfox[nb-1]!=0x2b);
       Relais_Write(1);
       CyDelay(3000);
       Relais_Write(0);*/
    //reception message du serveur sigfox
    }
  }
/********************************************END Envoi Sigfox********************************************/
/********************************************START Reception Sigfox********************************************/
/********************************************END Envoi Sigfox********************************************/

/*-XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX-VOID MAIN-XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX-*/
int main(void)
{
    CyGlobalIntEnable; 
    
    
    uint8 niv_puits;
    
    
    
    /*isr_rbat_Stop();
    isr_rch_Stop();
    isr_vbat_Stop();
    isr_vpan_Stop();*/
    
    
    sigfox_init();
    Relais_Write(0); 
    for(;;)
    {       
    lecture_reserv();
    //lecture_leds();
     
/*START communication UART PUITS*/
    UART_XBEE_Start();
        
    /*START requete puits*/
    UART_XBEE_PutString("$puits,");
    /*END requete puits*/
    
    /*START lecture données puits*/
     /* if((niv_puits = UART_XBEE_GetChar())!=0)
            {
                   
            }*/
    //niv_puits='02';
        
    /*END lecture donnees puits*/
/*END communication uart*/
        
        
        
    /*START envoi données Sigfox*/
        
    /*END envoi données Sigfox*/
    data[0]=1;   //A SUPPRIMER !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    data[1]=2;   //A SUPPRIMER !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    data[2]=3;   //A SUPPRIMER !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    data[3]=0; 
    data[4]=1;   //A SUPPRIMER !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    data[5]=2;   //A SUPPRIMER !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    sigfox_send();
    CyDelay(1000000);    
        
 
    
}
}

   
/* [] END OF FILE */